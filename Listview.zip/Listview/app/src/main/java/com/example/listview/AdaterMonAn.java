package com.example.listview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class AdaterMonAn extends BaseAdapter {

    private Context context;
    private int layout;
    private List<MonAn> arrylist;

    public AdaterMonAn(Context context, int layout, List<MonAn> arrylist) {
        this.context = context;
        this.layout = layout;
        this.arrylist = arrylist;
    }

    @Override
    public int getCount() {
        return arrylist.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        return null;
    }

    public View getView(int i, View view,View convertView,ViewGroup viewGroup) {

        LayoutInflater inflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflate.inflate(layout,null);
        MonAn  monAn = arrylist.get(i);


        TextView textV1= convertView.findViewById(R.id.name);
        TextView textV2 = convertView.findViewById(R.id.mota);
        ImageView imageV= convertView.findViewById(R.id.imageHinh);

        textV1.setText(monAn.getTenmon());
        textV2.setText(monAn.getMota());
        imageV.setImageResource(monAn.getHinh());
    return convertView;
    }
}
