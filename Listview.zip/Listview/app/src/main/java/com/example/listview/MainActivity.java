package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_monan);

        ListView listview;
        ArrayList<MonAn> arrayList;
        AdaterMonAn adapter;

        listview = findViewById(R.id.listviewmonan);
        arrayList = new ArrayList<>();
        arrayList.add(new MonAn("Mì Xào","ĐƠN GIÁ : 30.000 VNĐ",R.drawable.mixao));

        adapter = new AdaterMonAn(MainActivity.this,R.layout.layout_monan,arrayList);
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i==0){
                    Intent intent = new Intent();
                    intent.setClass(MainActivity.this,MainActivity2.class );
                    startActivity(intent);
                }
            }
        });
    }
}